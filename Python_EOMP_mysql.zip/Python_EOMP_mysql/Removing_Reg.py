from tkinter import *
import mysql.connector
from tkinter import messagebox

from PIL.Image import ID

control = Tk()
control.geometry("600x600")
control.title("Control room")
control.configure(background="skyblue")


# IMAGE
photo = PhotoImage(file="images//download.png")
w = Label(control, image=photo)
w.place(x=80, y=0)

mydb = mysql.connector.connect(user='lifechoices', password='@Lifechoices1234',
                               host='127.0.0.1', database='lifechoiceonline',
                               auth_plugin='mysql_native_password')
mycursor = mydb.cursor()


# MAIN MENU FUNCTION
def main():
    ext = messagebox.askyesno(title="main menu", message="Are you sure?")
    if ext == True:
        control.destroy()
    else:
        return None
    import main_menu


# ADMIN REGISTERING
def regAdmin():
    control.destroy()
    import admin_registering


# REMOVE USERS
def delete():
    passs= identity.get()
    mydb = mysql.connector.connect(
      user='lifechoices', password='@Lifechoices1234', host='127.0.0.1', database='lifechoiceonline', auth_plugin='mysql_native_password')

    mycursor = mydb.cursor()

    sql = "DELETE FROM Registered WHERE ID = %s"
    user_id = (int(passs),)
    mycursor.execute(sql, (user_id))

    mydb.commit()
    messagebox.showinfo("Successfully", "You have successfully deleted uder")
    control.destroy()
    import Admin_control







# # USERNAME
# lbluser = Label(control, text="Full names", font="bold")
# lbluser.place(x=150, y=170)
# username = Entry(control, width=45)
# username.place(x=150, y=200, width=200, height="30")

# PASSWORD
lblpassword = Label(control, text="Enter ID", font="bold")
lblpassword.place(x=150, y=200)
identity = Entry(control, width=45)
identity.place(x=150, y=230, width=200, height="30")

# REMOVE
removebtn = Button(control, text="Remove users", font="bold", background="lime", width="20", command=delete)
removebtn.place(x=150, y=300)


# MAIN MENU
showbtn = Button(control, text="Main menu", font="bold", background="lime", width="20", command=main)
showbtn.place(x=150, y=350)

control.mainloop()
