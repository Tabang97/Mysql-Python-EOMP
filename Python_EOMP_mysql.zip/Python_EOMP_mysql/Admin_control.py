from tkinter import *
import mysql.connector
from tkinter import messagebox

control = Tk()
control.geometry("600x600")
control.title("Control room")
control.configure(background="skyblue")



# IMAGE
photo = PhotoImage(file="images//download.png")
w = Label(control, image=photo)
w.place(x=80, y=0)

mydb = mysql.connector.connect(user='lifechoices', password='@Lifechoices1234',
                               host='127.0.0.1', database='lifechoiceonline',
                               auth_plugin='mysql_native_password')
mycursor = mydb.cursor()


# MAIN MENU FUNCTION
def main():
    ext = messagebox.askyesno(title="main menu", message="Are you sure?")
    if ext == True:
        control.destroy()
    else:
        return None
    import main_menu


# ADMIN REGISTERING
def regAdmin():
    control.destroy()
    import admin_registering


# REMOVE USERS
def delete():
    control.destroy()
    import Removing_Reg

# SHOW LOGGED
def show():
    mydb = mysql.connector.connect(user='lifechoices', password='@Lifechoices1234',
                                   host='127.0.0.1', database='lifechoiceonline',
                                   auth_plugin='mysql_native_password')
    mycursor = mydb.cursor()
    mycursor.execute("SELECT * FROM log")
    myresult = mycursor.fetchall()
    control.destroy()
    import show_logged

# SHOW LOGGED IN & OUT
showbtn = Button(control, text="Show Logged", font="bold", background="lime", width=25, command=show)
showbtn.place(x=120, y=280)

# REGIST ADMIN
adminbtn = Button(control, text="Register Admin", font="bold", background="lime", command=regAdmin, width=25)
adminbtn.place(x=120, y=320)

# REMOVE
removebtn = Button(control, text="Delete users", font="bold", background="lime", command=delete, width=25)
removebtn.place(x=120, y=360)

# MAIN MENU
showbtn = Button(control, text="Main menu", font="bold", background="lime", command=main, width=25)
showbtn.place(x=120, y=400)

control.mainloop()

