from tkinter import *
import mysql.connector
from tkinter import messagebox
window = Tk()
window.geometry("700x700")
window.title("Register Page")
window.configure(background="skyblue")


# photo
photo = PhotoImage(file="images//download.png")
w = Label(window, image=photo)
w.place(x=80, y=0)

mydb = mysql.connector.connect(user='lifechoices', password='@Lifechoices1234',
                               host='127.0.0.1', database='lifechoiceonline',
                               auth_plugin='mysql_native_password')
mycursor = mydb.cursor()


# BACK FUNCTION
def back():
    ext = messagebox.askyesno(title="Exit", message="are you sure you want to go back?")
    if ext == True:
        window.withdraw()
    else:
        return None
    window.destroy()
    import Admin_login


def insert():

    user = username.get()
    idntity = IDentry.get()
    phone = callentry.get()
    address = adrsEntry.get()
    gender= radiobtn.get()

    sql = "INSERT INTO Registered (Full_names, ID, Contact, Address, Gender) VALUES(%s, %s, %s, %s, %s)"
    val = (user, idntity, phone, address, gender)

    mycursor.execute(sql, val)
    mydb.commit()
    messagebox.showinfo("Successfully", "You have successfully Registered")
    window.destroy()
    import login_page








# FULLNAME
lbluser = Label(window, text="Full Name", font="bold")
lbluser.place(x=110, y=180)
username = Entry(window, width=45)
username.place(x=110, y=210, width=300, height="30")

# ID
lblID = Label(window, text="ID No.", font="bold")
lblID.place(x=110, y=250)
IDentry = Entry(window, width=45)
IDentry.place(x=110, y=280, width=300, height="30")

# CONTACT
lblphone = Label(window, text="Contact No.", font="bold")
lblphone.place(x=110, y=320)
callentry = Entry(window, width=45)
callentry.place(x=110, y=350, width=300, height="30")

# ADDRESS
lbladdress = Label(window, text="Address", font="bold")
lbladdress.place(x=110, y=390)
adrsEntry = Entry(window, width=45)
adrsEntry.place(x=110, y=420, width=300, height="30")

# GENDER
gender = Label(window, text="Gender", font="bold")
gender.place(x=110, y=460)
radiobtn = Entry(window, text="Male")
radiobtn.place(x=110, y=480, width=300, height="30")




jstlbl = Label(window, text="__________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________", background="skyblue")
jstlbl.place(x=0, y=520)

# REGISTER BUTTON
btn = Button(window, text="Register", background="lime", command=insert)
btn.place(x=150, y=570)

# BACK BUTTON
Bbtn = Button(window, text="Back", background="blue", command=back)
Bbtn.place(x=300, y=570)


window.mainloop()
