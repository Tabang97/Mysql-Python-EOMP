# Password & Username = Tabang, 1234

from tkinter import *
import mysql.connector
from tkinter import messagebox


root = Tk()
root.geometry("500x600")
root.title("Main menu")
root.configure(background="skyblue")

# photo
photo = PhotoImage(file="images//download.png")
w = Label(root, image=photo)
w.place(x=80, y=0)

mydb = mysql.connector.connect(user='lifechoices', password='@Lifechoices1234',
                               host='127.0.0.1', database='lifechoiceonline',
                               auth_plugin='mysql_native_password')

mycursor = mydb.cursor()


# Login function
def admin():
    root.destroy()
    import login_page

# LOGIN USER
def reg():
    users = userentr.get()
    passs = password.get()
    sql = "select * from user where Username = %s and Password = %s"
    mycursor.execute(sql, [users, passs])
    results = mycursor.fetchall()
    if results:
        for i in results:
            logged()
            break
    else:
        failed()



def logged():
    messagebox.showinfo("Successfully", "You have successfully logged")
    root.destroy()
    import user_page


# if login details are incorrect
def failed():
    messagebox.showinfo("Error", "try again")
    username.delete(0, END)
    password.delete(0, END)
    root.destroy()


# QUIT FUNCTION
def close():
    ext = messagebox.askyesno(title="Exit", message="are you sure you want to exit?")
    if ext == True:
        root.destroy()
    else:
        return None

# USERNAME
username = Label(root, text="Username", font="bold")
username.place(x=100, y=200)
userentr = Entry(root)
userentr.place(x=100, y=230, width=280, height="30")

# PASSWORD
lblpassword = Label(root, text="password", font="bold")
lblpassword.place(x=100, y=265)
password = Entry(root, show="*")
password.place(x=100, y=300, width=280, height="30")

# LOG USER
btn = Button(root, text="Log user", background="lime", width=30, command=reg)
btn.place(x=100, y=400)

# ADMIN BUTTON
btn = Button(root, text="Admin", background="lime", width=30, command=admin)
btn.place(x=100, y=450)

# QUIT BUTTON
Qbtn = Button(root, text="Exit", background="red", width=30, command=close)
Qbtn.place(x=100, y=500)
root.mainloop()
