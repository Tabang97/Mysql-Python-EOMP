from tkinter import *
import mysql.connector
from tkinter import messagebox


root = Tk()
root.geometry("500x600")
root.title("Admin register")
root.configure(background="skyblue")

# photo
photo = PhotoImage(file="images//download.png")
w = Label(root, image=photo)
w.place(x=80, y=0)

mydb = mysql.connector.connect(user='lifechoices', password='@Lifechoices1234',
                               host='127.0.0.1', database='lifechoiceonline',
                               auth_plugin='mysql_native_password')

mycursor = mydb.cursor()




def register():

    user = username.get()
    passs = password.get()


    sql = "INSERT INTO Login (username,password) VALUES( %s, %s)"
    val = (user, passs, )

    mycursor.execute(sql, val)
    mydb.commit()
    messagebox.showinfo("Successfully", "You have successfully Registered")
    root.destroy()
    import login_page




# QUIT FUNCTION
def close():
    ext = messagebox.askyesno(title="Exit", message="are you sure you want to exit?")
    if ext == True:
        root.destroy()
    else:
        return None

# USERNAME
lbluser = Label(root, text="username", font="bold")
lbluser.place(x=110, y=170)
username = Entry(root, width=45)
username.place(x=110, y=200, width=200, height="30")

# PASSWORD
lblpassword = Label(root, text="password", font="bold")
lblpassword.place(x=110, y=250)
password = Entry(root, width=45, show="*")
password.place(x=110, y=300, width=200, height="30")

# LOGIN BUTTON
btn = Button(root, text="Register", background="lime",  width=30, command=register)
btn.place(x=70, y=360)

# QUIT BUTTON
Qbtn = Button(root, text="Exit", background="red", width=30, command=close)
Qbtn.place(x=70, y=430)
root.mainloop()
