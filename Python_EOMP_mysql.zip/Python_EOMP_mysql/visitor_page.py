from tkinter import *
import mysql.connector
from tkinter import messagebox

visit = Tk()
visit.geometry("700x700")
visit.title("Visitor Register")
visit.configure(background="skyblue")


# photo
photo = PhotoImage(file="images//download.png")
w = Label(visit, image=photo)
w.place(x=80, y=0)

mydb = mysql.connector.connect(user='lifechoices', password='@Lifechoices1234',
                               host='127.0.0.1', database='lifechoiceonline',
                               auth_plugin='mysql_native_password')
mycursor = mydb.cursor()


def insert():
    user = username.get()
    call = callEntr.get()
    stay = livingEnt.get()

    sql = "INSERT INTO Visitors (Full_names, Contacts, Address) VALUES(%s, %s, %s)"
    val = (user, call, stay)

    mycursor.execute(sql, val)
    mydb.commit()
    messagebox.showinfo("Successfully", "You have successfully Registered")
    visit.destroy()
    import login_page


# BACK FUNCTION
def back():
    ext = messagebox.askyesno(title="Back", message="are you sure you want to cancel?")
    if ext == True:
        visit.destroy()
        import Admin_login
    else:
        return None


# FULLNAME
lbluser = Label(visit, text="Full Name", font="bold")
lbluser.place(x=110, y=180)
username = Entry(visit, width=45)
username.place(x=110, y=210, width=300, height="30")

# CONTACT
lblphone = Label(visit, text="Contact No.", font="bold")
lblphone.place(x=110, y=280)
callEntr = Entry(visit, width=45)
callEntr.place(x=110, y=310, width=300, height="30")

# ADDRESS
lbladdress = Label(visit, text="Address", font="bold")
lbladdress.place(x=110, y=390)
livingEnt = Entry(visit, width=45)
livingEnt.place(x=110, y=420, width=300, height="30")


# Register button
btn = Button(w, text="Register user", background="lime")
btn.place(x=140, y=440)


# JST LABEL
jstlbl = Label(visit, text="__________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________", background="skyblue")
jstlbl.place(x=0, y=500)

# REGISTER BUTTON
btn = Button(visit, text="Register", background="lime", command=insert)
btn.place(x=150, y=550)

# BACK BUTTON
Bbtn = Button(visit, text="Back", background="blue", command=back)
Bbtn.place(x=300, y=550)


visit.mainloop()
