# must register someone first to log them in or out, if already registere just punch their detail then log

from tkinter import *
import mysql.connector
from tkinter import messagebox
root = Tk()
root.geometry("500x600")
root.title("user page")
root.configure(background="skyblue")

# photo
photo = PhotoImage(file="images//download.png")
w = Label(root, image=photo)
w.place(x=80, y=0)

mydb = mysql.connector.connect(user='lifechoices', password='@Lifechoices1234',
                               host='127.0.0.1', database='lifechoiceonline',
                               auth_plugin='mysql_native_password')

mycursor = mydb.cursor()

# REGISTRATION
def reg():
    root.destroy()
    import register2


# QUIT FUNCTION
def close():
    ext = messagebox.askyesno(title="Exit", message="are you sure you want to exit?")
    if ext == True:
        root.destroy()
    else:
        return None

def log():
    time_out = userentr.get()
    sql = "UPDATE Registered set signin=curtime() where Full_names=%s"
    mycursor.execute(sql, (time_out,))
    messagebox.showinfo("logIn", "successfully logged In")
    mydb.commit()

    user = userentr.get()

    sql = 'SELECT * FROM Registered WHERE Full_names=%s'
    mycursor.execute(sql, (user,))

    results = mycursor.fetchall()
    if results:
        # messagebox.showinfo("Successfully", "You have successfully Registered")
        root.destroy()
        import show_logged
    else:
        messagebox.showinfo("Error", "please try again")

def out():
    time_out = userentr.get()
    sql = "UPDATE Registered set signout=curtime() where Full_names=%s"
    mycursor.execute(sql, (time_out,))
    messagebox.showinfo("log out", "successfully logged out")
    mydb.commit()

    user = userentr.get()

    sql = 'SELECT * FROM Registered WHERE Full_names=%s'
    mycursor.execute(sql, (user,))

    results = mycursor.fetchall()
    if results:
        # messagebox.showinfo("Successfully", "You have successfully Registered")
        root.destroy()
        import show_logged
    else:
        messagebox.showinfo("Error", "please try again")

    # user = userentr.get()
    # sql = 'SELECT * FROM Registered WHERE Full_names=%s'
    # mycursor.execute(sql, (user,))
    #
    # results = mycursor.fetchall()
    # if results:
    #     messagebox.showinfo("Successfully", "You have successfully Registered")
    #     root.destroy()
    #     import show_logged
    # else:
    #     messagebox.showinfo("Error", "please try again")


def back():
    messagebox.showinfo("Error", "Are you sure?")
    root.destroy()
    import main_menu

# LOGIN
username = Label(root, text="Enter Full name", font="bold")
username.place(x=100, y=200)
userentr = Entry(root)
userentr.place(x=100, y=230, width=280, height="30")

#LOGIN
btn = Button(root, text="Login", background="lime", width=5, command=log)
btn.place(x=100, y=280)

#LOGout
btn = Button(root, text="Logout", background="lime", width=5, command=out)
btn.place(x=310, y=280)

#REGISTER
btn = Button(root, text="Register", background="lime", width=30, command=reg)
btn.place(x=100, y=340)

# BACK BUTTON
Bbtn = Button(root, text="Back", background="blue", width=30, command=back)
Bbtn.place(x=100, y=410)

# QUIT BUTTON
Qbtn = Button(root, text="Exit", background="red", width=30, command=close)
Qbtn.place(x=100, y=460)
root.mainloop()
