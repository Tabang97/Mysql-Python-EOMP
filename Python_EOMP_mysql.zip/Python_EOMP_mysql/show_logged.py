from tkinter import *
import mysql.connector
from tkinter import messagebox
root = Toplevel()
root.geometry("700x700")
root.title("logged ppl")
root.configure(background="skyblue")

display = Listbox(root, width=200)
display.place(x=5, y=140)

# photo
photo = PhotoImage(file="images//download.png")
w = Label(root, image=photo)
w.place(x=80, y=0)

mydb = mysql.connector.connect(user='lifechoices', password='@Lifechoices1234', host='127.0.0.1', database='lifechoiceonline',
                               auth_plugin='mysql_native_password')

mycursor = mydb.cursor()
sql = "select * from Registered"
mycursor.execute(sql)
for i in mycursor:
    display.insert('end', i)

# QUIT FUNCTION
def Exit():
    ext = messagebox.askyesno(title="Exit", message="are you sure you want to exit?")
    if ext == True:
        root.destroy()
    else:
        return None

def back():
    ext = messagebox.askyesno(title="Back", message="are you sure you want to cancel?")
    if ext == True:
        root.withdraw()
        import Admin_control

# REGISTER BUTTON
btn = Button(root, text="back", background="lime", command=back)
btn.place(x=150, y=550)

# BACK BUTTON
Xbtn = Button(root, text="Exit", background="blue", command=Exit)
Xbtn.place(x=300, y=550)

root.mainloop()
