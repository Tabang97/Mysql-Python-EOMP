from tkinter import messagebox
from tkinter import *
import mysql.connector








mydb = mysql.connector.connect(user='lifechoices', password='@Lifechoices1234',
                               host='127.0.0.1', database='lifechoiceonline',
                               auth_plugin='mysql_native_password')
mycursor = mydb.cursor()
root = Tk()
root.geometry("600x600")
root.title("Admin page")
root.configure(background="skyblue")
# photo
photo = PhotoImage(file="images//download.png")
w = Label(root, image=photo)
w.place(x=80, y=0)




# register function
def register():
    root.destroy()
    import register

# VISITOR FUNCTION
def visit():
    root.destroy()
    import visitor_page


def back():
    ext = messagebox.askyesno(title="Back", message="are you sure you want to go to previous page?")
    if ext == True:
        root.destroy()
    else:
        return None
    import login_page

# QUIT FUNCTION
def close():
    ext = messagebox.askyesno(title="Exit", message="are you sure you want to exit?")
    if ext == True:
        root.destroy()
    else:
        return None



def clicker():
    root.destroy()
    import Admin_control


# REGISTER BUTTON
btn = Button(root, text="Register user", background="lime", font="bold", height="3", width="20", command=register)
btn.place(x=170, y=190)


# VISITOR BUTTON
vbtn = Button(root, text="Register visitor", background="lime",  font="bold", height="3", width="20", command=visit)
vbtn.place(x=170, y=290)

# ADMIN CHANGES
adbtn = Button(root, text="admin", background="lime",  font="bold", height="3", width="20", command=clicker)
adbtn.place(x=170, y=390)

# BACK BUTTON
Bbtn = Button(root, text="Back", background="blue", command=back)
Bbtn.place(x=170, y=490)

# QUIT BUTTON
Qbtn = Button(root, text="Exit", background="red", command=close)
Qbtn.place(x=340, y=490)
root.mainloop()



root.mainloop()
